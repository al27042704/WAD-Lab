const InstagramProfile={
    username:"sidra123433",
    name:"sidra",
    posts:0,
    followers:64,
    following:617,
    bio: {
        religion:"Muslim",
        nationality:"Pakistani",
        profession:"Nutritionist",
        interest: "White lover"
    },
    followedBy: ["moizzahhere", "ubaidKashmiri836", "2 others"],
    profilePicture: "insta.jpg" 
};
console.log(InstagramProfile);