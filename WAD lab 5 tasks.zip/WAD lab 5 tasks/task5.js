let num = prompt("Enter a number:"); 
num = Number(num); 
if (num % 3 === 0) {
    alert("The number is a multiple of 3.");
} else {
    alert("The number is not a multiple of 3.");
}
