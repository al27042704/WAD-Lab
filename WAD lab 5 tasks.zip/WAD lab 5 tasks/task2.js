const Product={
    name:"PakWheels Waterless & Glass Cleaner",
    category:"Car Cleaning",
    originalPrice:1198,
    discountPercentage:20,
    discountedPrice:958,
    brand:"PakWheels"
};
console.log(Product);