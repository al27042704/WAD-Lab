let bigIntValue=123456789012345678901234567890n;
let symbolValue=Symbol("unique");
console.log(typeof bigIntValue);
console.log(typeof symbolValue);