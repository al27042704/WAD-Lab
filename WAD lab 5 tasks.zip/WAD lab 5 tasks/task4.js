let a = 5;
console.log(a++); 
console.log(++a); 
console.log(a--); 
console.log(--a); 