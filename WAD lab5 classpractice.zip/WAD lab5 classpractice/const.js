const pi = 3.1416;
console.log(pi); // Output: 3.1416

// pi = 3.14;  Error: Assignment to constant variable

if (true) {
    const city = "Lahore";
    console.log(city); // Output: Lahore
}
// console.log(city); //  Error: city is not defined
