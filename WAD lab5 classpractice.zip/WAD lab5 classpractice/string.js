var str1="Hello World";
var str2='Hello World';
console.log(str1);
console.log(str2);