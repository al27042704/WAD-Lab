var int=100;
var float=100.5;
var hex=0xfff;
var exponential=2.56e3;
console.log(typeof int);
console.log(typeof float);
console.log(typeof hex);
console.log(typeof exponential);