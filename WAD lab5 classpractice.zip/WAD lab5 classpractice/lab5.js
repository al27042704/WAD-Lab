console.log("ALEENA SAEED");
fullName="Aleena Saeed";
age=19;
price=99.99;
radius=14;
a=null;
y=undefined;
console.log(fullName);
