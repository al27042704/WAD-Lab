if (5*2==10) {
    console.log("Your answer is correct")
} else {
    console.log("Your answer is incorrect")
}