let a=5;
let b=2;
console.log("a=",a,"& b=",b);

console.log("a++=",a++);
console.log("a=",a);