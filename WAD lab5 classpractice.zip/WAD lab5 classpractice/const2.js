const student= {
    fullName:"Aleena Saeed",
    age:19,
    cgpa:8.2,
    isPass:true
};
student["age"]=student["age"]+1;
console.log(student["age"]);