<script>
    var fruittype = prompt ("Konsa fal chaiye?");
    switch (fruittype) {
        case 'Narangi':
            console.log('Narangi has 60rs Kilo.');
            break;
        case 'Sabe':
            console.log('Sabe hai 100rs Kilo');
            break;
        case 'Kele':
            console.log('Kele are 35rs Kilo.');
            break;
        case 'Amrudh':
            console.log('Amrudh hai 80rs Kilo.');
            break;
        case 'Aam':
            console.log('Aam diya 300rs Dozen.');
            break;
        case 'Papita':
            console.log('Aam ne Papita dono 300rs Dozen.');
            break;
        default:
            console.log('s{fruittype} aaj khatam hogya kal ayega.');
    }
    console.log("0rr Kuch chaiye Hukum?");
</script>