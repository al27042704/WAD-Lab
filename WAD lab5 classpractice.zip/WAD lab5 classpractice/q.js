<script>
    Let num=prompt(Let num=prompt (“enter a number”))
    var time=prompt("Hey Whats the time: ");
    if(time>5 && time<17){
        alert("Good Morning")
    } 
    else{
        alert("Good Evening")
    }
</script>
