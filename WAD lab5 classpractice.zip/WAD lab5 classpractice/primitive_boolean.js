var YES=true;
var NO=false;

if(YES)
{
    alert("This code block will be executed");
}

if(NO)
{
    alert("This code block will not be executed");
}
