canYouDoThisForMe();

function canYouDoThisForMe(){
    var yaSure = "I can do anything you want";
    return yaSure;
}