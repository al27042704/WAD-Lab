var myVar;
alert(myVar); //undefined